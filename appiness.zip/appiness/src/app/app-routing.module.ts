import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ShowallComponent } from './showall/showall.component';
import { EditComponent } from './edit/edit.component';

const routes: Routes = [
  {path: 'home' , component : HomeComponent},
  {path: 'showall',component:ShowallComponent },
  {path:'edit/:number',component:EditComponent},
  {path : 'edit', component : EditComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
