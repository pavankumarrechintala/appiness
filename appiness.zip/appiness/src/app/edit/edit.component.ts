import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  registerForm: FormGroup;
  
  constructor(private acr : ActivatedRoute,private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(6)]],
      email: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')]],
      textarea: ['', [Validators.required, Validators.minLength(15), Validators.maxLength(30)]],
      state: ['', [Validators.required]],
      url: ['', [Validators.required]],
      number: ['', Validators.required],
      datetime: ['', Validators.required],
    });

    

    this.acr.params.subscribe(params=>{
      const data = this.acr.snapshot.data;
    
  });
  this.acr.params.subscribe(routeParam => {
    var data = routeParam['number'];
  
    console.log(data);
  });
   
  }
getreg(number : number){
  
}
}
