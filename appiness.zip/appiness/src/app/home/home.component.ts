import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  registerForm: FormGroup;
  constructor(private formBuilder: FormBuilder, private rt: Router ) {
    
   }


  
  

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(6)]],
      email: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')]],
      textarea: ['', [Validators.required, Validators.minLength(15), Validators.maxLength(30)]],
      state: ['', [Validators.required]],
      url: ['', [Validators.required]],
      number: ['', Validators.required],
      datetime: ['', Validators.required],
    });

  }


  
  onSubmit() {
    
    if (this.registerForm.valid) {

      alert(JSON.stringify(this.registerForm.value))
      localStorage.setItem('register', JSON.stringify(this.registerForm.value))
  
      this.rt.navigate(['/showall'])
    }
    else {
      alert("enter valid details")
    }

  }

}
