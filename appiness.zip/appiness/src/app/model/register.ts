export class registerForm{
    firstname : string;
    email : string;
    url : number;
    number : number;
    state : string;
    description : string;
    datetime  : Date
}               