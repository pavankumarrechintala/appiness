import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-showall',
  templateUrl: './showall.component.html',
  styleUrls: ['./showall.component.css']
})
export class ShowallComponent implements OnInit {
  localobj: any[]= [];
  lobj: any[];
  constructor(private rt : Router) {
    
   }
  ngOnInit() {  
    console.log("register body"+JSON.parse(localStorage.getItem('register')))
              
    this.localobj.push(JSON.parse(localStorage.getItem('register1')))
    this.localobj.push(JSON.parse(localStorage.getItem('register')))
    
  }
  edit(lst: number){
    
    console.log(lst);
    this.rt.navigate(['/edit',lst])

  }       
    
}
